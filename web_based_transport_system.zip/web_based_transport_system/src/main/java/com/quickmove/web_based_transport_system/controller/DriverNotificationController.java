package com.quickmove.web_based_transport_system.controller;

import com.quickmove.web_based_transport_system.entity.Payment;
import com.quickmove.web_based_transport_system.entity.Ride;
import com.quickmove.web_based_transport_system.service.RideService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.util.Map;

@Controller
public class DriverNotificationController {

    @Autowired
    private RideService rideService;

    @MessageMapping("/rideRequest")
    @SendTo("/topic/rideRequests")
    public Ride sendRideRequest(Ride ride) {
        return ride; // Broadcast new ride request to all available drivers
    }

    // NEW: For Manual Payment Requests
    @MessageMapping("/paymentRequest")
    @SendTo("/topic/paymentRequests")
    public Map<String, Object> sendPaymentRequest(Map<String, Object> paymentRequest) {
        return paymentRequest; // Broadcast to drivers: {rideId, amount, userId}
    }

    // NEW: For Payment Updates (to users/drivers)
    @MessageMapping("/paymentUpdate")
    @SendTo("/topic/paymentUpdates")
    public Payment sendPaymentUpdate(Payment payment) {
        return payment;
    }
}