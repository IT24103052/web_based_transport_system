package com.quickmove.web_based_transport_system.repository;

import com.quickmove.web_based_transport_system.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
}