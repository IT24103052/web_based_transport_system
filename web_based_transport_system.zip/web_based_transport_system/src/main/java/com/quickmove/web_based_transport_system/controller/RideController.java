package com.quickmove.web_based_transport_system.controller;

import com.quickmove.web_based_transport_system.entity.Ride;
import com.quickmove.web_based_transport_system.service.PaymentService;
import com.quickmove.web_based_transport_system.service.RideService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rides")
public class RideController {

    @Autowired
    private RideService rideService;

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/book")
    public ResponseEntity<Map<String, Object>> bookRide(@RequestBody Map<String, String> rideRequest) {
        try {
            String userId = rideRequest.get("userId");
            String vehicleType = rideRequest.get("vehicleType");
            String pickupLocation = rideRequest.get("pickupLocation");
            String dropoffLocation = rideRequest.get("dropoffLocation");
            Double fare = Double.valueOf(rideRequest.getOrDefault("fare", "0.0"));

            if (userId == null || vehicleType == null || pickupLocation == null) {
                return ResponseEntity.badRequest().body(Map.of(
                        "status", "error",
                        "message", "Missing required fields: userId, vehicleType, or pickupLocation"
                ));
            }

            Ride ride = new Ride();
            ride.setUserId(userId);
            ride.setVehicleType(vehicleType);
            ride.setFare(fare);
            ride.setDropoffLocation(dropoffLocation);

            Ride savedRide = rideService.createRide(ride, pickupLocation);
            return ResponseEntity.ok().body(Map.of(
                    "id", savedRide.getId(),
                    "status", "success",
                    "pickup", pickupLocation,
                    "dropoff", dropoffLocation,
                    "vehicleType", vehicleType,
                    "duration", savedRide.getDuration(),
                    "distance", savedRide.getDistance()
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("status", "error", "message", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("status", "error", "message", "Internal server error: " + e.getMessage()));
        }
    }

    @GetMapping("/available-drivers")
    public ResponseEntity<List<String>> getAvailableDrivers(@RequestParam String pickupLocation) {
        return ResponseEntity.ok().body(rideService.getAvailableDrivers(pickupLocation));
    }

    @PutMapping("/update-location")
    public ResponseEntity<Map<String, Object>> updateRideLocation(@RequestBody Map<String, String> updateRequest) {
        try {
            Long id = Long.valueOf(updateRequest.get("id"));
            String pickupLocation = updateRequest.get("pickupLocation");
            String dropoffLocation = updateRequest.get("dropoffLocation");

            if (id == null || pickupLocation == null || dropoffLocation == null) {
                return ResponseEntity.badRequest().body(Map.of(
                        "status", "error",
                        "message", "Missing required fields: id, pickupLocation, or dropoffLocation"
                ));
            }

            Ride updatedRide = rideService.updateRideLocation(id, pickupLocation, dropoffLocation);
            if (updatedRide != null) {
                return ResponseEntity.ok().body(Map.of(
                        "status", "success",
                        "message", "Locations updated",
                        "id", id,
                        "pickup", pickupLocation,
                        "dropoff", dropoffLocation,
                        "duration", updatedRide.getDuration(),
                        "distance", updatedRide.getDistance()
                ));
            } else {
                return ResponseEntity.status(404).body(Map.of(
                        "status", "error",
                        "message", "Ride not found"
                ));
            }
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Invalid ride ID format"));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("status", "error", "message", "Internal server error: " + e.getMessage()));
        }
    }

    @DeleteMapping("/cancel/{id}")
    public ResponseEntity<Void> cancelRide(@PathVariable Long id) {
        return rideService.cancelRide(id)
                ? ResponseEntity.ok().build()
                : ResponseEntity.notFound().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ride> getRideById(@PathVariable Long id) {
        Ride ride = rideService.getRideById(id);
        return ride != null
                ? ResponseEntity.ok().body(ride)
                : ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<Ride>> getAllRides() {
        return ResponseEntity.ok().body(rideService.getAllRides());
    }

    @PostMapping("/assignDriverToRide")
    public ResponseEntity<Map<String, Object>> assignDriverToRide(@RequestParam Long driverId, @RequestParam Long rideId) {
        boolean success = rideService.assignDriverToRide(driverId, rideId);
        return success
                ? ResponseEntity.ok().body(Map.of("status", "success"))
                : ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Invalid state"));
    }

    @PostMapping("/rejectRide")
    public ResponseEntity<Map<String, Object>> rejectRide(@RequestParam Long driverId, @RequestParam Long rideId) {
        boolean success = rideService.rejectRide(driverId, rideId);
        return success
                ? ResponseEntity.ok().body(Map.of("status", "success"))
                : ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Invalid state"));
    }

    @PostMapping("/startRide")
    public ResponseEntity<Map<String, Object>> startRide(@RequestParam Long driverId, @RequestParam Long rideId) {
        boolean success = rideService.startRide(driverId, rideId);
        return success
                ? ResponseEntity.ok().body(Map.of("status", "success"))
                : ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Invalid state"));
    }

    @PostMapping("/completeRide")
    public ResponseEntity<Map<String, Object>> completeRide(@RequestParam Long driverId, @RequestParam Long rideId) {
        boolean success = rideService.completeRide(driverId, rideId);
        return success
                ? ResponseEntity.ok().body(Map.of("status", "success"))
                : ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Invalid state"));
    }

    @MessageMapping("/rideRequests")
    @SendTo("/topic/rideRequests")
    public Ride handleRideRequest(Ride ride) {
        return ride;
    }

    // NEW: GET Ride + Payment Details
    @GetMapping("/{id}/payment")
    public ResponseEntity<Map<String, Object>> getRidePaymentDetails(@PathVariable Long id) {
        Ride ride = rideService.getRideById(id);
        if (ride == null) {
            return ResponseEntity.notFound().build();
        }
        var payments = paymentService.getAllPayments();
        var payment = payments.stream().filter(p -> p.getRideId().equals(id)).findFirst().orElse(null);

        Map<String, Object> details = Map.of(
                "rideId", ride.getId(),
                "userId", ride.getUserId(),
                "vehicleType", ride.getVehicleType(),
                "driverId", ride.getDriverId(),
                "amount", ride.getFare(),
                "status", ride.getStatus()
        );
        if (payment != null) {
            ((Map<String, Object>) details).put("paymentId", payment.getId());
            ((Map<String, Object>) details).put("method", payment.getMethod());
            ((Map<String, Object>) details).put("paymentStatus", payment.getStatus());
        }
        return ResponseEntity.ok(details);
    }
}