package com.quickmove.web_based_transport_system.service;

import com.quickmove.web_based_transport_system.entity.Payment;
import com.quickmove.web_based_transport_system.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    public Payment savePayment(Payment payment) {
        validatePayment(payment);
        Payment savedPayment = paymentRepository.save(payment);
        notifyPaymentUpdate(savedPayment);
        return savedPayment;
    }

    public Payment updatePaymentStatus(Long id, String status) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));
        if (!status.matches("PENDING|SUCCESSFUL|FAILED|REJECTED")) {
            throw new IllegalArgumentException("Status must be PENDING, SUCCESSFUL, FAILED, or REJECTED");
        }
        payment.setStatus(status);
        Payment updatedPayment = paymentRepository.save(payment);
        notifyPaymentUpdate(updatedPayment);
        return updatedPayment;
    }

    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));
    }

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public void deletePayment(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));
        paymentRepository.delete(payment);
    }

    public Payment confirmPayment(Long id, Payment confirmationDetails) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found"));
        if (!"PENDING".equals(payment.getStatus())) {
            throw new IllegalArgumentException("Payment must be in PENDING status to confirm");
        }
        payment.setMethod(confirmationDetails.getMethod());
        payment.setCardNumber(confirmationDetails.getCardNumber());
        payment.setCvc(confirmationDetails.getCvc());
        payment.setRideId(confirmationDetails.getRideId());
        payment.setUserId(confirmationDetails.getUserId());
        payment.setDriverId(confirmationDetails.getDriverId());
        payment.setVehicleType(confirmationDetails.getVehicleType());
        payment.setAmount(confirmationDetails.getAmount());
        validatePayment(payment);
        if ("CARD".equals(payment.getMethod())) {
            payment.setStatus("SUCCESSFUL"); // Simulate card success
        } else {
            payment.setStatus("PENDING"); // Manual stays PENDING until driver accepts
        }
        Payment confirmedPayment = paymentRepository.save(payment);
        notifyPaymentUpdate(confirmedPayment);
        return confirmedPayment;
    }

    private void validatePayment(Payment payment) {
        if (payment.getRideId() == null || payment.getRideId() <= 0) {
            throw new IllegalArgumentException("Ride ID must be provided and valid");
        }
        if (payment.getUserId() == null || payment.getUserId().isEmpty()) {
            throw new IllegalArgumentException("User ID must be provided");
        }
        if (payment.getDriverId() == null || payment.getDriverId().isEmpty()) {
            throw new IllegalArgumentException("Driver ID must be provided");
        }
        if (payment.getAmount() == null || payment.getAmount() <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero");
        }
        if (payment.getMethod() == null || !payment.getMethod().matches("MANUAL|CARD")) {
            throw new IllegalArgumentException("Payment method must be MANUAL or CARD");
        }
        if (payment.getStatus() == null || !payment.getStatus().matches("PENDING|SUCCESSFUL|FAILED|REJECTED")) {
            throw new IllegalArgumentException("Status must be PENDING, SUCCESSFUL, FAILED, or REJECTED");
        }
        if ("CARD".equals(payment.getMethod())) {
            if (payment.getCardNumber() == null || !payment.getCardNumber().matches("\\d{16}")) {
                throw new IllegalArgumentException("Valid 16-digit card number required for CARD payment");
            }
            if (payment.getCvc() == null || !payment.getCvc().matches("\\d{3}")) {
                throw new IllegalArgumentException("Valid 3-digit CVC required for CARD payment");
            }
        }
    }

    private void notifyPaymentUpdate(Payment payment) {
        messagingTemplate.convertAndSend("/topic/paymentUpdates/" + payment.getRideId(), payment); // Use rideId for topic
        messagingTemplate.convertAndSendToUser(payment.getUserId(), "/queue/payments", payment);
        messagingTemplate.convertAndSendToUser(payment.getDriverId(), "/queue/payments", payment);
    }
}